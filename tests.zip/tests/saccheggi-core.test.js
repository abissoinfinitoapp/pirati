const test = require("node:test");
const assert = require("node:assert/strict");
const core = require("../engine/saccheggi-core.js");

test("un tentativo consumato resta indisponibile soltanto nello stesso giorno", () => {
  assert.equal(core.dayAvailable({ usedDay: 8 }, 8), false);
  assert.equal(core.dayAvailable({ usedDay: 8 }, 9), true);
});

test("pickPair esclude le ultime quattro coppie quando restano alternative", () => {
  const pairs = ["a", "b", "c", "d", "e", "f"].map(id => ({ id }));
  assert.equal(core.pickPair(pairs, ["a", "b", "c", "d"], () => 0).id, "e");
});

test("scoreRolls somma statistiche e bonus di squadra", () => {
  const players = [
    { id: "p1", stats: { astuzia: 3 } },
    { id: "p2", stats: { astuzia: 1 } }
  ];
  const score = core.scoreRolls(players, { p1: 4, p2: 6 }, "astuzia", 1);
  assert.deepEqual(score.entries.map(x => x.total), [7, 7]);
  assert.equal(score.average, 8);
});

test("il primo fallimento porta alla seconda scelta, il secondo chiude", () => {
  assert.deepEqual(core.resolveAttempt(5.9, 6, 1), { success: false, nextPhase: "retry-choice" });
  assert.deepEqual(core.resolveAttempt(5.9, 6, 2), { success: false, nextPhase: "result" });
  assert.deepEqual(core.resolveAttempt(6, 6, 2), { success: true, nextPhase: "result" });
});

test("raidLossPenalty: un quarto del carico in monete, mai più di quel che c'è nel forziere", () => {
  const ship = { rewards: [{ type: "coins", amount: 800000 }, { type: "loot", id: "x" }] };
  assert.equal(core.raidLossPenalty(ship, 1000000), 200000);
  assert.equal(core.raidLossPenalty(ship, 100000), 100000, "non può scendere sotto zero: si limita a quel che c'è");
  assert.equal(core.raidLossPenalty(ship, 0), 0);
});

test("raidLossPenalty: se la nave non ha monete tra i premi usa una base di sicurezza", () => {
  const ship = { rewards: [{ type: "loot", id: "solo-oggetto" }] };
  assert.equal(core.raidLossPenalty(ship, 999999999), 25000);
});

test("withRaidDefaults inizializza lo stato e conserva valori validi", () => {
  assert.deepEqual(core.withRaidDefaults({}), {
    usedDay: null,
    pairId: null,
    shipId: null,
    attempt: 1,
    phase: "idle",
    rolls: {},
    outcome: null,
    recentPairIds: [],
    returnTo: "map",
    rewardsApplied: false
  });
  assert.deepEqual(core.withRaidDefaults({ usedDay: 4, recentPairIds: ["p1"], rolls: { p1: 5 } }), {
    usedDay: 4,
    pairId: null,
    shipId: null,
    attempt: 1,
    phase: "idle",
    rolls: { p1: 5 },
    outcome: null,
    recentPairIds: ["p1"],
    returnTo: "map",
    rewardsApplied: false
  });
});

test("withRaidDefaults non condivide rolls e recentPairIds con il salvataggio", () => {
  const saved = { rolls: { p1: 4 }, recentPairIds: ["pair-1"] };
  const raid = core.withRaidDefaults(saved);

  raid.rolls.p1 = 6;
  raid.recentPairIds.push("pair-2");

  assert.equal(saved.rolls.p1, 4);
  assert.deepEqual(saved.recentPairIds, ["pair-1"]);
});

test("applyRaidRewardsOnce assegna ricompense una sola volta", () => {
  const state = {
    day: 3,
    fame: 2,
    crew: { coins: 1, fame: 99, loot: [] },
    raid: { rewardsApplied: false }
  };
  const ship = {
    id: "nave-gelato",
    rewards: [
      { type: "coins", amount: 3 },
      { type: "fame", amount: 2 },
      { type: "loot", id: "gelato" }
    ]
  };

  assert.equal(core.applyRaidRewardsOnce(state, ship), true);
  assert.equal(state.crew.coins, 4);
  assert.equal(state.fame, 4);
  assert.deepEqual(state.crew.loot, [{ id: "gelato", questId: null, day: 3 }]);
  assert.equal(state.raid.rewardsApplied, true);
  assert.equal(core.applyRaidRewardsOnce(state, ship), false);
  assert.equal(state.crew.coins, 4);
  assert.equal(state.fame, 4);
  assert.deepEqual(state.crew.loot, [{ id: "gelato", questId: null, day: 3 }]);
});

test("applyRaidRewardsOnce rifiuta uno stato raid non oggetto senza lanciare", () => {
  const state = { raid: "malformato", crew: { coins: 1, loot: [] }, fame: 2 };

  assert.doesNotThrow(() => assert.equal(core.applyRaidRewardsOnce(state, {
    rewards: [{ type: "coins", amount: 3 }]
  }), false));
  assert.equal(state.crew.coins, 1);
  assert.equal(state.fame, 2);
});

test("applyRaidRewardsOnce rifiuta uno stato crew array senza assegnare", () => {
  const state = { raid: { rewardsApplied: false }, crew: [], fame: 2 };

  assert.doesNotThrow(() => assert.equal(core.applyRaidRewardsOnce(state, {
    rewards: [{ type: "coins", amount: 3 }]
  }), false));
  assert.deepEqual(state.crew, []);
  assert.equal(state.fame, 2);
  assert.equal(state.raid.rewardsApplied, false);
});
